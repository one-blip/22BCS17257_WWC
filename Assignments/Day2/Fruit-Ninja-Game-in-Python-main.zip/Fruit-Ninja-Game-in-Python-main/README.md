# Create-Fruit-Ninja-Game-in-Python

The objective of this project is to build a fruit ninja game with python. This game is built with the help of pygame module and basic concept of python.

In this game, the user has to cut the fruits by touching the mouse on fruits. There are also bombs with fruits. If the mouse touches more than three bombs then the game will be over.
